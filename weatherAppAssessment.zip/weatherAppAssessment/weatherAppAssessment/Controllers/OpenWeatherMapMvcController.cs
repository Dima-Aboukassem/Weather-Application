﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Configuration;
using System.Web.Services;
using weatherAppAssessment.Models;
using weatherAppAssessment.DimaClass;
using Newtonsoft.Json;
using System.Text;
using System.Net;
using System.IO;

namespace weatherAppAssessment.Controllers
{
    public class OpenWeatherMapMvcController : Controller
    {
        // https://www.codeproject.com/Articles/1180283/How-to-Implement-OpenWeatherMap-API-in-ASP-NET-MVC
        // GET: OpenWeatherMapMvc
        public ActionResult Index()
        {
            OpenWeatherMap openWeatherMap = ChooseCity();

            return View(openWeatherMap);
        }
        public OpenWeatherMap ChooseCity()
        {
            OpenWeatherMap openWeatherMap = new OpenWeatherMap();
            openWeatherMap.cities= new Dictionary<string, string>();
            openWeatherMap.cities.Add("Jablah", "169304");
            openWeatherMap.cities.Add("Damascus", "170654");
            openWeatherMap.cities.Add("Tartouss", "163345");
            openWeatherMap.cities.Add("Spokan", "5811696");
            openWeatherMap.cities.Add("Olympia", "5811696");
            openWeatherMap.cities.Add("Kirkland", "5799841");
            openWeatherMap.cities.Add("Portland", "5746545");
            return openWeatherMap;
        }
        [HttpPost]
        public ActionResult Index(OpenWeatherMap openWeatherMap, string cities)
        {
            openWeatherMap = ChooseCity();

            if (cities != null)
            {
                /*Calling API http://openweathermap.org/api */
                string apiKey = "Your API KEY";
                HttpWebRequest apiRequest = 
                    WebRequest.Create("https://maps.googleapis.com/maps/api/js?key=7c253c40820752a018c81e43cd6955b2&callback=initMap" + cities + "&appid=" + apiKey + "&units=metric") as HttpWebRequest;

                string apiResponse = "";
                using (HttpWebResponse response = apiRequest.GetResponse() as HttpWebResponse)
                {
                    StreamReader reader = new StreamReader(response.GetResponseStream());
                    apiResponse = reader.ReadToEnd();
                }
                /*End*/

                /*http://json2csharp.com*/
                ResponseWeather rootObject = JsonConvert.DeserializeObject<ResponseWeather>(apiResponse);

                StringBuilder sb = new StringBuilder();
                sb.Append("<table><tr><th>Weather Description</th></tr>");
                sb.Append("<tr><td>City:</td><td>" + rootObject.name + "</td></tr>");
                sb.Append("<tr><td>Country:</td><td>" + rootObject.system.country + "</td></tr>");
                sb.Append("<tr><td>Wind:</td><td>" + rootObject.wind.speed + " Km/h</td></tr>");
                sb.Append("<tr><td>Current Temperature:</td><td>" + rootObject.main.temp + " °C</td></tr>");
                sb.Append("<tr><td>Humidity:</td><td>" + rootObject.main.humidity + "</td></tr>");
                sb.Append("<tr><td>Weather:</td><td>" + rootObject.weather[0].description + "</td></tr>");
                sb.Append("</table>");
                openWeatherMap.apiResponse = sb.ToString();
            }
            else
            {
                if (Request.Form["submit"] != null)
                {
                    openWeatherMap.apiResponse = "► Select City";
                }
            }
            return View(openWeatherMap);
        }
    }

}


