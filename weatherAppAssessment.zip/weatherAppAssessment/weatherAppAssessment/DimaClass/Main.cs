﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace weatherAppAssessment.DimaClass
{
    public class Main
    {
        public double temp { get; set; }
        public int pressure { get; set; }
        public int humidity { get; set; }
        public int temp_min { get; set; }
        public int temp_max { get; set; }
    }
}